package guillermoli;

import static org.junit.Assert.*;
import org.junit.Test;

public class HashSimpleTest {
    @Test
    public void hashSimple1() {
        Hasheador hasheador = new Hasheador();
        // Hernandez Chi 58785
        assertEquals("33", hasheador.hashSimple("58785"));
    }

    @Test
    public void hashSimple2() {
        Hasheador hasheador = new Hasheador();
        // Hernandez Gonzales 58772
        assertEquals("29", hasheador.hashSimple("58772"));
    }

    @Test
    public void hashSimple3() {
        Hasheador hasheador = new Hasheador();
        // Lopez Lopez 58753
        assertEquals("28", hasheador.hashSimple("58753"));
    }

    @Test
    public void hashSimple4() {
        Hasheador hasheador = new Hasheador();
        // Saravia Dzib 56551
        assertEquals("22", hasheador.hashSimple("56551"));
    }

    @Test
    public void hashSimpleMio(){
        Hasheador hasheador = new Hasheador();
        // Guillermo Li 50323
        assertEquals("13", hasheador.hashSimple("50323"));
    }

}
