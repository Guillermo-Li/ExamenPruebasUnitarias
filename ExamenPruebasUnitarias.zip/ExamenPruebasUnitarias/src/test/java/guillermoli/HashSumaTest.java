package guillermoli;

import org.junit.Test;
import static org.junit.Assert.*;

public class HashSumaTest {
    @Test
    public void hashSuma1() {
        Hasheador hasheador = new Hasheador();
        // Hernandez Chi 58785
        assertEquals("REPROBADO", hasheador.hashSumado(hasheador.hashSimple("58785")));
    }

    @Test
    public void hashSuma2() {
        Hasheador hasheador = new Hasheador();
        // Hernandez Gonzales 58772
        assertEquals("EGGXELENT!", hasheador.hashSumado(hasheador.hashSimple("58772")));
    }

    @Test
    public void hashSuma3() {
        Hasheador hasheador = new Hasheador();
        // Lopez Lopez 58753
        assertEquals("EGGXELENT!", hasheador.hashSumado(hasheador.hashSimple("58753")));
    }

    @Test
    public void hashSuma4() {
        Hasheador hasheador = new Hasheador();
        // Saravia Dzib 56551
        assertEquals("REPROBADO", hasheador.hashSumado(hasheador.hashSimple("56551")));
    }

    @Test
    public void hashSumaMio(){
        Hasheador hasheador = new Hasheador();
        // Guillermo Li 50323
        assertEquals("REPROBADO", hasheador.hashSumado(hasheador.hashSimple("50323")));
    }
}
