package guillermoli;

public class Hasheador {

    public static void main(String[] args) {
        String matricula = "56551";

        Hasheador hasheador = new Hasheador();
        System.out.println(hasheador.hashSumado(hasheador.hashSimple(matricula)));;
    }

    public  String hashSimple(String matricula){
        String hashSimplificado = "";
        int suma = 0;

        for (int x = 0; x < matricula.length(); x++){
             suma += Integer.parseInt(String.valueOf(matricula.charAt(x)));
        }
//        System.out.println("suma: " + suma);

        hashSimplificado = Integer.toString(suma);
//        System.out.println("hashsimplificado: " + hashSimplificado);

        return hashSimplificado;
    }

    public  String hashSumado(String hashSimple){
        String calificación = "";
        String hashSumado = "";
        int suma = 0;

        for (int x = 0; x < hashSimple.length(); x++){
            suma += Integer.parseInt(String.valueOf(hashSimple.charAt(x)));
        }
//        System.out.println("suma: " + suma);

        hashSumado = Integer.toString(suma);
//        System.out.println("hashsimplificado: " + hashSumado);

        if (suma < 7){
            calificación = "REPROBADO";
        } else if (6 < suma && suma < 10){
            calificación = "Aprobado";
        } else if (suma > 9){
            calificación = "EGGXELENT!";
        } else {
            calificación = "No hay, no existe >:v";
        }

//        System.out.println(calificación);

        return calificación;
    }
}
