package org.example;

import static org.junit.Assert.*;
import org.junit.Test;

public class UsingTheAndOperatorTest {

    @Test
    public void andTester(){
        UsingTheAndOperator usingTheAndOperator = new UsingTheAndOperator();

        assertEquals(false, usingTheAndOperator.andOperator(true, false));
        assertEquals(true, usingTheAndOperator.andOperator(true, true));
        assertEquals(false, usingTheAndOperator.andOperator(false, true));
        assertEquals(false, usingTheAndOperator.andOperator(false, false));
    }
}
