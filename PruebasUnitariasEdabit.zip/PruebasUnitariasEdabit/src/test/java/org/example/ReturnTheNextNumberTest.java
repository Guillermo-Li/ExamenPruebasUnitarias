package org.example;

import static org.junit.Assert.*;
import org.junit.Test;

public class ReturnTheNextNumberTest {

    @Test
    public void addTest(){
        ReturnTheNextNumber returnTheNextNumber = new ReturnTheNextNumber();

        assertEquals(1, returnTheNextNumber.añadirNumero(0));
        assertEquals(10, returnTheNextNumber.añadirNumero(9));
        assertEquals(-2, returnTheNextNumber.añadirNumero(-3));
    }
}
