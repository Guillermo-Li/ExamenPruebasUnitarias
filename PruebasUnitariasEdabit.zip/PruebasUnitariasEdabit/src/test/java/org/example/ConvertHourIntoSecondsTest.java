package org.example;

import static org.junit.Assert.*;
import org.junit.Test;

public class ConvertHourIntoSecondsTest {

    @Test
    public void hoursToSecondsTst(){
        ConvertHourIntoSeconds convertHourIntoSeconds = new ConvertHourIntoSeconds();

        assertEquals(7200, convertHourIntoSeconds.howManySeconds(2));
        assertEquals(36000, convertHourIntoSeconds.howManySeconds(10));
        assertEquals(   86400, convertHourIntoSeconds.howManySeconds(24));
    }

}
