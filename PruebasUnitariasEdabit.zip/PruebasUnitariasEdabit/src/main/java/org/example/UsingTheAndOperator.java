package org.example;

public class UsingTheAndOperator {
    public static boolean andOperator(boolean a, boolean b) {
        if (a){
            if (b){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
