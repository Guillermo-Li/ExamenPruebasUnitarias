package org.example;

public class ReturnTheNextNumber {
    public static int añadirNumero(int num) {
        return num+1;
    }
}
