package org.example;

public class ConvertHourIntoSeconds {
    public static int howManySeconds(int hours) {
        return hours*3600;
    }
}
